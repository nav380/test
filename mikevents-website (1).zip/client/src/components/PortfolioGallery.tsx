/**
 * Portfolio Gallery Component
 * Masonry-style photo gallery with category filters and lightbox functionality
 * Dark theme with saffron accents
 */

import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, ZoomIn, ChevronLeft, ChevronRight } from "lucide-react";

type Category = "All" | "Conferences" | "Exhibitions" | "Corporate" | "Incentive Travel" | "Associations";

interface PortfolioItem {
  id: number;
  title: string;
  category: Category;
  imageUrl: string;
  description: string;
  client?: string;
  attendees?: string;
  year?: string;
}

export default function PortfolioGallery() {
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<PortfolioItem | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Portfolio items - replace with actual event photos
  const portfolioItems: PortfolioItem[] = [
    {
      id: 1,
      title: "International Medical Conference 2025",
      category: "Conferences",
      imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=600&fit=crop",
      description: "3-day international medical conference with 500+ delegates",
      client: "Indian Medical Association",
      attendees: "500+",
      year: "2025"
    },
    {
      id: 2,
      title: "Tech Expo India",
      category: "Exhibitions",
      imageUrl: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&h=1000&fit=crop",
      description: "Large-scale technology exhibition with 100+ exhibitors",
      client: "Tech Industry Council",
      attendees: "2000+",
      year: "2024"
    },
    {
      id: 3,
      title: "Corporate Annual Summit",
      category: "Corporate",
      imageUrl: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&h=600&fit=crop",
      description: "Fortune 500 company annual leadership summit",
      client: "Confidential",
      attendees: "300+",
      year: "2025"
    },
    {
      id: 4,
      title: "Bali Incentive Trip",
      category: "Incentive Travel",
      imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=1000&fit=crop",
      description: "5-day luxury incentive travel program in Bali",
      client: "Leading FMCG Company",
      attendees: "150",
      year: "2024"
    },
    {
      id: 5,
      title: "Engineering Association AGM",
      category: "Associations",
      imageUrl: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=800&h=600&fit=crop",
      description: "Annual General Meeting with networking dinner",
      client: "National Engineering Association",
      attendees: "200+",
      year: "2025"
    },
    {
      id: 6,
      title: "Product Launch Event",
      category: "Corporate",
      imageUrl: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&h=800&fit=crop",
      description: "High-profile product launch with media coverage",
      client: "Tech Startup",
      attendees: "400+",
      year: "2024"
    },
    {
      id: 7,
      title: "Healthcare Conference 2024",
      category: "Conferences",
      imageUrl: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=800&h=600&fit=crop",
      description: "National healthcare conference with CME credits",
      client: "Healthcare Federation",
      attendees: "600+",
      year: "2024"
    },
    {
      id: 8,
      title: "Auto Expo Pavilion",
      category: "Exhibitions",
      imageUrl: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&h=1000&fit=crop",
      description: "Custom pavilion design for auto expo",
      client: "Leading Automobile Brand",
      attendees: "5000+",
      year: "2025"
    },
    {
      id: 9,
      title: "Dubai Incentive Program",
      category: "Incentive Travel",
      imageUrl: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&h=600&fit=crop",
      description: "Luxury incentive program in Dubai",
      client: "Insurance Company",
      attendees: "100",
      year: "2024"
    },
    {
      id: 10,
      title: "Finance Summit 2025",
      category: "Conferences",
      imageUrl: "https://images.unsplash.com/photo-1591115765373-5207764f72e7?w=800&h=800&fit=crop",
      description: "Banking and finance industry summit",
      client: "Banking Association",
      attendees: "800+",
      year: "2025"
    },
    {
      id: 11,
      title: "Trade Fair Management",
      category: "Exhibitions",
      imageUrl: "https://images.unsplash.com/photo-1464047736614-af63643285bf?w=800&h=600&fit=crop",
      description: "International trade fair with B2B matchmaking",
      client: "Export Promotion Council",
      attendees: "3000+",
      year: "2024"
    },
    {
      id: 12,
      title: "Team Building Retreat",
      category: "Corporate",
      imageUrl: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=800&h=1000&fit=crop",
      description: "3-day team building retreat in mountains",
      client: "IT Services Company",
      attendees: "80",
      year: "2025"
    }
  ];

  const categories: Category[] = ["All", "Conferences", "Exhibitions", "Corporate", "Incentive Travel", "Associations"];

  const filteredItems = selectedCategory === "All" 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedCategory);

  const openLightbox = (item: PortfolioItem, index: number) => {
    setSelectedImage(item);
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    const newIndex = direction === 'next' 
      ? (currentIndex + 1) % filteredItems.length 
      : (currentIndex - 1 + filteredItems.length) % filteredItems.length;
    
    setCurrentIndex(newIndex);
    setSelectedImage(filteredItems[newIndex]);
  };

  return (
    <section className="py-20" style={{ background: "#ffffff" }}>
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border-0" style={{ background: "#fef2f2", color: "#a20504" }}>
            Our Portfolio
          </Badge>
          <h2 className="text-[#1a0000] mb-4">
            Showcasing <span className="text-gradient-saffron">Excellence</span> in Every Event
          </h2>
          <p className="text-xl text-[#6b6b6b] max-w-3xl mx-auto">
            Explore our portfolio of successful events across conferences, exhibitions, corporate gatherings, and incentive travel programs.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
              className={`
                ${selectedCategory === category 
                  ? 'bg-[#a20504] text-white shadow-lg' 
                  : 'bg-[#f8f8f8] text-[#6b6b6b] border-[#e8e8e8] hover:border-[#a20504]/50 hover:text-[#c41e1c]'
                }
                transition-all duration-300
              `}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Masonry Gallery Grid */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="break-inside-avoid group relative overflow-hidden rounded-xl border border-[#e8e8e8] hover:border-[#a20504]/50 transition-all duration-300 cursor-pointer bg-[#f8f8f8]"
              onClick={() => openLightbox(item, index)}
            >
              {/* Image */}
              <div className="relative overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className="bg-[#a20504]/20 text-[#c41e1c] border-[#a20504]/30 text-xs">
                        {item.category}
                      </Badge>
                      <ZoomIn className="w-5 h-5 text-[#1a0000]" />
                    </div>
                    <h3 className="text-[#1a0000] font-bold text-lg mb-2">{item.title}</h3>
                    <p className="text-[#6b6b6b] text-sm">{item.description}</p>
                  </div>
                </div>
              </div>

              {/* Info Bar */}
              <div className="p-4 bg-[#f8f8f8]">
                <h4 className="text-[#1a0000] font-semibold mb-2">{item.title}</h4>
                <div className="flex items-center gap-4 text-xs text-[#6b6b6b]">
                  {item.attendees && <span>👥 {item.attendees}</span>}
                  {item.year && <span>📅 {item.year}</span>}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-20">
            <p className="text-[#9ca3af] text-lg">No events found in this category.</p>
          </div>
        )}

        {/* Instructions for adding photos */}
        <div className="mt-16 text-center">
          <div className="inline-block bg-[#f8f8f8] border border-[#a20504]/30 rounded-lg px-6 py-4 max-w-2xl">
            <p className="text-[#c41e1c] text-sm font-medium mb-2">
              📸 To Add Your Event Photos:
            </p>
            <p className="text-[#6b6b6b] text-sm">
              Replace the placeholder images in <code className="bg-[#e8e8e8] px-2 py-1 rounded text-[#c41e1c]">PortfolioGallery.tsx</code> with your actual event photo URLs. 
              Upload high-quality images (800-1200px width recommended) and update the <code className="bg-[#e8e8e8] px-2 py-1 rounded text-[#c41e1c]">portfolioItems</code> array with event details.
            </p>
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxOpen && selectedImage && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          {/* Close Button */}
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 z-[110] w-12 h-12 bg-[#f8f8f8]/80 hover:bg-[#a20504] text-[#1a0000] rounded-full flex items-center justify-center transition-all"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Previous Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateLightbox('prev');
            }}
            className="absolute left-4 z-[110] w-12 h-12 bg-[#f8f8f8]/80 hover:bg-[#a20504] text-[#1a0000] rounded-full flex items-center justify-center transition-all"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateLightbox('next');
            }}
            className="absolute right-4 z-[110] w-12 h-12 bg-[#f8f8f8]/80 hover:bg-[#a20504] text-[#1a0000] rounded-full flex items-center justify-center transition-all"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content */}
          <div 
            className="max-w-6xl w-full bg-[#f8f8f8] rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="grid md:grid-cols-2 gap-0">
              {/* Image */}
              <div className="relative bg-black">
                <img
                  src={selectedImage.imageUrl}
                  alt={selectedImage.title}
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Details */}
              <div className="p-8 flex flex-col justify-between">
                <div>
                  <Badge className="mb-4 bg-[#a20504]/20 text-[#c41e1c] border-[#a20504]/30">
                    {selectedImage.category}
                  </Badge>
                  <h2 className="text-[#1a0000] text-2xl font-bold mb-4">{selectedImage.title}</h2>
                  <p className="text-[#6b6b6b] text-lg mb-6">{selectedImage.description}</p>
                  
                  <div className="space-y-3">
                    {selectedImage.client && (
                      <div className="flex items-start gap-3">
                        <span className="text-[#a20504] font-semibold min-w-[100px]">Client:</span>
                        <span className="text-[#6b6b6b]">{selectedImage.client}</span>
                      </div>
                    )}
                    {selectedImage.attendees && (
                      <div className="flex items-start gap-3">
                        <span className="text-[#a20504] font-semibold min-w-[100px]">Attendees:</span>
                        <span className="text-[#6b6b6b]">{selectedImage.attendees}</span>
                      </div>
                    )}
                    {selectedImage.year && (
                      <div className="flex items-start gap-3">
                        <span className="text-[#a20504] font-semibold min-w-[100px]">Year:</span>
                        <span className="text-[#6b6b6b]">{selectedImage.year}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-[#e8e8e8]">
                  <p className="text-[#9ca3af] text-sm">
                    Image {currentIndex + 1} of {filteredItems.length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
