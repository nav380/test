/**
 * Contact Section Component
 * Design Philosophy: Neo-Brutalism with Warmth
 * Features: Contact form, direct contact methods, location info
 */

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Phone, Mail, MapPin, MessageCircle, Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    service: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form submission logic would go here
    toast.success("Thank you! We'll get back to you within 24 hours.");
    setFormData({
      name: "",
      email: "",
      phone: "",
      company: "",
      service: "",
      message: ""
    });
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20" style={{ background: "#f8f8f8" }}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-14">
          <span className="inline-block text-xs font-bold uppercase tracking-widest px-4 py-1.5 rounded-full mb-4" style={{ background: '#fef2f2', color: '#a20504' }}>Get In Touch</span>
          <h2 className="text-3xl md:text-4xl font-bold mb-3" style={{ color: '#1a0000' }}>
            Let's Plan Your Next Event
          </h2>
          <div className="section-divider" />
          <p className="mt-5 text-lg text-[#6b6b6b] max-w-2xl mx-auto">
            Ready to create magic together? Reach out to us and let's discuss how we can make your next event extraordinary.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl p-8" style={{ background: '#ffffff', border: '1px solid #e8e8e8', boxShadow: '0 4px 24px rgba(162,5,4,0.06)' }}>
              <h3 className="text-xl font-bold mb-6" style={{ color: '#1a0000' }}>Send Us a Message</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name" className="text-[#1a0000] font-semibold mb-2 block">
                      Your Name *
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange("name", e.target.value)}
                      required
                      className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-[#1a0000] font-semibold mb-2 block">
                      Email Address *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange("email", e.target.value)}
                      required
                      className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]"
                      placeholder="john@company.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phone" className="text-[#1a0000] font-semibold mb-2 block">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleChange("phone", e.target.value)}
                      className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]"
                      placeholder="+91 98765 43210"
                    />
                  </div>
                  <div>
                    <Label htmlFor="company" className="text-[#1a0000] font-semibold mb-2 block">
                      Company Name
                    </Label>
                    <Input
                      id="company"
                      value={formData.company}
                      onChange={(e) => handleChange("company", e.target.value)}
                      className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]"
                      placeholder="Your Company"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="service" className="text-[#1a0000] font-semibold mb-2 block">
                    Service Interest *
                  </Label>
                  <Select value={formData.service} onValueChange={(value) => handleChange("service", value)}>
                    <SelectTrigger className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="association">Association Management</SelectItem>
                      <SelectItem value="conference">Conference Management</SelectItem>
                      <SelectItem value="meeting">Meeting Management</SelectItem>
                      <SelectItem value="exhibition">Exhibition Management</SelectItem>
                      <SelectItem value="incentive">Incentive Travel Management</SelectItem>
                      <SelectItem value="consulting">Consulting Services</SelectItem>
                      <SelectItem value="other">Other / Not Sure</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="message" className="text-[#1a0000] font-semibold mb-2 block">
                    Your Message *
                  </Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleChange("message", e.target.value)}
                    required
                    rows={5}
                    className="border-2 border-[#e8e8e8] focus:border-[#a20504] focus:ring-orange-500 bg-white text-[#1a0000]"
                    placeholder="Tell us about your event requirements..."
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full btn-crimson flex items-center justify-center gap-2 py-3 text-base"
                >
                  <Send className="mr-2" /> Send Message
                </Button>

                <p className="text-sm text-[#6b6b6b] text-center">
                  We'll respond within 24 hours during business days
                </p>
              </form>
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Phone */}
            <div className="rounded-xl p-5" style={{ background: '#ffffff', border: '1px solid #e8e8e8' }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#fef2f2' }}><Phone className="w-5 h-5" style={{ color: '#a20504' }} /></div><div><p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#a20504' }}>Call Us</p><p className="text-sm font-medium" style={{ color: '#1a0000' }}>+91 (Contact Number)</p></div>
              </div>
            </div>

            {/* Email */}
            <div className="rounded-xl p-5" style={{ background: '#ffffff', border: '1px solid #e8e8e8' }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#fef2f2' }}><Mail className="w-5 h-5" style={{ color: '#a20504' }} /></div><div><p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#a20504' }}>Email Us</p><a href="mailto:info@mikevents.in" className="text-sm font-medium" style={{ color: '#1a0000', textDecoration: 'none' }}>info@mikevents.in</a></div>
              </div>
            </div>

            {/* WhatsApp */}
            <div className="rounded-xl p-5" style={{ background: '#ffffff', border: '1px solid #e8e8e8' }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#fef2f2' }}><MessageCircle className="w-5 h-5" style={{ color: '#a20504' }} /></div><div><p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#a20504' }}>WhatsApp</p><a href="https://wa.me/91" className="text-sm font-medium" style={{ color: '#1a0000', textDecoration: 'none' }}>Chat with us</a></div>
              </div>
            </div>

            {/* Location */}
            <div className="rounded-xl p-5" style={{ background: '#ffffff', border: '1px solid #e8e8e8' }}>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#fef2f2' }}><MapPin className="w-5 h-5" style={{ color: '#a20504' }} /></div><div><p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#a20504' }}>Location</p><p className="text-sm font-medium" style={{ color: '#1a0000' }}>Pan-India Operations</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
