/**
 * Client Logos Section Component
 * Dark theme with saffron accents
 */

import { Badge } from "@/components/ui/badge";

export default function ClientLogos() {
  // Placeholder logo data - replace with actual client logos
  const clients = [
    { name: "Fortune 500 Company 1", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 2", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 3", logo: "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 4", logo: "https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 5", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 6", logo: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 7", logo: "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 8", logo: "https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 9", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 10", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 11", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=200&h=100&fit=crop" },
    { name: "Fortune 500 Company 12", logo: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=200&h=100&fit=crop" },
  ];

  return (
    <section className="py-20 bg-white border-y border-[#e8e8e8]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-gradient-to-r from-[#a20504] to-[#c41e1c] text-[#1a0000] px-4 py-1 border-0">
            Trusted By Industry Leaders
          </Badge>
          <h2 className="text-[#1a0000] mb-4">
            Our <span className="text-gradient-saffron">Prestigious</span> Clients
          </h2>
          <p className="text-[#6b6b6b] text-lg max-w-2xl mx-auto">
            Partnering with Fortune 500 companies, government bodies, and leading associations to deliver exceptional events.
          </p>
        </div>

        {/* Logos Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-8">
          {clients.map((client, index) => (
            <div
              key={index}
              className="group relative bg-[#f8f8f8] rounded-lg p-6 border border-[#e8e8e8] hover:border-[#a20504]/50 transition-all duration-300 hover:shadow-lg hover:shadow-[rgba(162,5,4,0.1)] flex items-center justify-center"
            >
              {/* Placeholder for client logo */}
              <div className="relative w-full h-16 flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-[#a20504]/10 to-[#c41e1c]/5 rounded opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative z-10 text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-br from-[#a20504] to-[#c41e1c] rounded-lg flex items-center justify-center">
                    <span className="text-[#1a0000] font-bold text-lg">{client.name.charAt(0)}</span>
                  </div>
                  <p className="text-xs text-[#9ca3af] group-hover:text-[#c41e1c] transition-colors">
                    Client Logo
                  </p>
                </div>
              </div>
              
              {/* Tooltip on hover */}
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-[#e8e8e8] text-[#1a0000] text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                {client.name}
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 rotate-45 w-2 h-2 bg-[#e8e8e8]" />
              </div>
            </div>
          ))}
        </div>

        {/* Instructions for adding logos */}
        <div className="mt-12 text-center">
          <div className="inline-block bg-[#f8f8f8] border border-[#a20504]/30 rounded-lg px-6 py-4 max-w-2xl">
            <p className="text-[#c41e1c] text-sm font-medium mb-2">
              📝 To Add Your Client Logos:
            </p>
            <p className="text-[#6b6b6b] text-sm">
              Replace the placeholder logos in <code className="bg-[#e8e8e8] px-2 py-1 rounded text-[#c41e1c]">ClientLogos.tsx</code> with your actual client logo URLs. 
              For best results, use transparent PNG logos on white background (200x100px recommended).
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
